#include <iostream>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <cmath>
#include <openssl/evp.h>
#include <limits> // Include this header for numeric_limits
#include <ctime>
using namespace std;

int sock;

void create_socket()
{
    // create the socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    // setup an address
    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(8080);
    connect(sock, (struct sockaddr *) &server_address, sizeof(server_address));
}

void encryptMessage(const char* message, char* encryptedMessage, unsigned long long sharedSecret, unsigned char* iv) {
    // Define the encryption key (128-bit from shared secret)
    unsigned char key[16];

    // Convert the shared secret key to a 128-bit key
    for (int i = 0; i < 16; i++) {
        key[i] = (sharedSecret >> (120 - 8 * i)) & 0xFF;
    }

    // Create an AES context for encryption
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv);  // Use the passed IV

    // Encrypt the message
    int len;
    int encryptedLen = 0;
    EVP_EncryptUpdate(ctx, (unsigned char*)encryptedMessage, &len, (const unsigned char*)message, strlen(message));
    encryptedLen += len;
    EVP_EncryptFinal_ex(ctx, (unsigned char*)encryptedMessage + encryptedLen, &len);
    encryptedLen += len;

    EVP_CIPHER_CTX_free(ctx);  // Free the context
}

// Function to decrypt message using AES-128 CBC
void decryptMessage(const char* encryptedMessage, char* decryptedMessage, unsigned long long sharedSecret, unsigned char* iv) {
    // Define the decryption key (128-bit from shared secret)
    unsigned char key[16];

    // Convert the shared secret key to a 128-bit key
    for (int i = 0; i < 16; i++) {
        key[i] = (sharedSecret >> (120 - 8 * i)) & 0xFF;
    }

    // Create an AES context for decryption
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv);  // Use the passed IV

    // Decrypt the message
    int len;
    int decryptedLen = 0;
    EVP_DecryptUpdate(ctx, (unsigned char*)decryptedMessage, &len, (const unsigned char*)encryptedMessage, strlen(encryptedMessage));
    decryptedLen += len;
    EVP_DecryptFinal_ex(ctx, (unsigned char*)decryptedMessage + decryptedLen, &len);
    decryptedLen += len;

    EVP_CIPHER_CTX_free(ctx);  // Free the context
    decryptedMessage[decryptedLen] = '\0';  // Null-terminate the decrypted message
}

// Function to handle login
void handleLogin(int client_socket) {
    // Receive login parameters from server
    char username[256], password[256];
    cout << "Enter username: ";
    cin.getline(username, sizeof(username));
    cout << "Enter password: ";
    cin.getline(password, sizeof(password));

    // Send login parameters to server
    send(client_socket, username, sizeof(username), 0);
    send(client_socket, password, sizeof(password), 0);
}

void handleRegistration(int client_socket) {
    // Receive registration parameters from server
    char email[256], username[256], password[256];
    cout << "Enter email: ";
    cin.getline(email, sizeof(email));
    cout << "Enter username: ";
    cin.getline(username, sizeof(username));
    cout << "Enter password: ";
    cin.getline(password, sizeof(password));

    // Send registration parameters to server
    send(client_socket, email, sizeof(email), 0);
    send(client_socket, username, sizeof(username), 0);
    send(client_socket, password, sizeof(password), 0);
}

// Function to perform Diffie-Hellman key exchange
void DH_key_exchange(int sock) {
    srand(time(NULL)); // Seed the random number generator

    // Define a small prime number and base
    const unsigned long long prime = 17;  // A prime number
    const unsigned long long alpha = 3;    // A base

    // Generate a random secret for the client
    unsigned long long clientSecret = rand() % (prime - 1) + 1; // Secret in range [1, prime-1]

    // Calculate the client's public value using the formula: clientPublic = (alpha^clientSecret) mod prime
    unsigned long long clientPublic = static_cast<unsigned long long>(pow(alpha, clientSecret)) % prime;

    // Send the client's public value to the server
    char clientPublicStr[256];
    snprintf(clientPublicStr, sizeof(clientPublicStr), "%llu", clientPublic); // Using snprintf for safety
    send(sock, clientPublicStr, strlen(clientPublicStr), 0); // Send the public value as a string

    // Receive the server's public value
    char serverPublicStr[256];
    recv(sock, serverPublicStr, sizeof(serverPublicStr), 0);
    unsigned long long serverPublic = strtoull(serverPublicStr, nullptr, 10); // Convert string to unsigned long long

    // Calculate the shared secret key using the formula: sharedSecret = (serverPublic^clientSecret) mod prime
    unsigned long long sharedSecret = static_cast<unsigned long long>(pow(serverPublic, clientSecret)) % prime;

    cout << "Client's Shared Secret Key: " << sharedSecret << endl;
    // Send the shared secret key to the server
    send(sock, reinterpret_cast<char*>(&sharedSecret), sizeof(sharedSecret), 0);
}


int main() {
    char buf[256];

    cout << "\n\t>>>>>>>>>> XYZ University Chat Client <<<<<<<<<<\n\n";
    
    // Create socket and connect to the server
    create_socket();

    int choice;
    cout<<"Enter your choice\n 1.Login\n 2.Register\n";
    cin>>choice;
    send(sock, &choice, sizeof(choice), 0);
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    
    if (choice == 1) 
    {
        handleLogin(sock);
    } 
    else if (choice == 2) 
    {
        handleRegistration(sock);

    }
    
     DH_key_exchange(sock);
     
    // Clear buffer before starting the chat
    memset(buf, 0, sizeof(buf));

    
  while (true) {
    // Step 1: Prepare the message to send to the server
    char message[256];
    cout << "Client: ";
    cin.getline(message, sizeof(message));

    // Check if the user wants to exit
    if (strcmp(message, "Exit") == 0) {
        send(sock, message, sizeof(message), 0);
        break;
    }

    // Step 2: Encrypt the message using the shared secret and IV
    unsigned long long sharedSecret;
    recv(sock, (char*)&sharedSecret, sizeof(sharedSecret), 0);  // Receive shared secret from server

    unsigned char iv[16];  // Create an IV for encryption
    RAND_bytes(iv, sizeof(iv));  // Generate a random IV for AES

    // Send the IV to the server
    send(sock, iv, sizeof(iv), 0);

    // Encrypt the message
    char encryptedMessage[256];
    encryptMessage(message, encryptedMessage, sharedSecret, iv);

    // Send the encrypted message to the server
    send(sock, encryptedMessage, sizeof(encryptedMessage), 0);

    // Step 3: Receive and decrypt the server's response
    char receivedEncryptedMessage[256];

    // Receive the encrypted message from the server
    recv(sock, receivedEncryptedMessage, sizeof(receivedEncryptedMessage), 0);

    // Receive the IV used by the server for decryption
    recv(sock, iv, sizeof(iv), 0);  // The server sends its IV

    // Decrypt the server's response
    char decryptedMessage[256];
    decryptMessage(receivedEncryptedMessage, decryptedMessage, sharedSecret, iv);

    // Print the decrypted message
    cout << "Server: " << decryptedMessage << endl;

    // Check if the server sent an exit message
    if (strcmp(decryptedMessage, "Exit") == 0) {
        break;
    }
}

    // Close the socket after communication
    close(sock);

    return 0;
}
