#include <iostream>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <cmath>
#include <openssl/evp.h>
#include <fstream>
#include <sstream>
#include <ctime>

using namespace std;

void decryptMessage(const char* encryptedMessage, char* decryptedMessage, unsigned long long sharedSecret, unsigned char* iv) {
    // Define the encryption key
    unsigned char key[16];

    // Convert the shared secret key to a 128-bit key
    for (int i = 0; i < 16; i++) {
        key[i] = (sharedSecret >> (120 - 8 * i)) & 0xFF;
    }

    // Create an AES context
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv);

    // Decrypt the message
    int len;
    int decryptedLen = 0;

    // Decrypt the encrypted message
    EVP_DecryptUpdate(ctx, (unsigned char*)decryptedMessage, &len, (const unsigned char*)encryptedMessage, strlen(encryptedMessage));
    decryptedLen += len;
    
    // Finalize the decryption
    EVP_DecryptFinal_ex(ctx, (unsigned char*)decryptedMessage + decryptedLen, &len);
    decryptedLen += len;

    EVP_CIPHER_CTX_free(ctx); // Free the context

    // Null-terminate the decrypted message
    decryptedMessage[decryptedLen] = '\0';
}


void encryptMessage(const char* message, char* encryptedMessage, unsigned long long sharedSecret, unsigned char* iv) {
    // Define the encryption key
    unsigned char key[16];

    // Convert the shared secret key to a 128-bit key
    for (int i = 0; i < 16; i++) {
        key[i] = (sharedSecret >> (120 - 8 * i)) & 0xFF;
    }

    // Create an AES context
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv);

    // Encrypt the message
    int len;
    int encryptedLen = 0;

    // Encrypt the plaintext message
    EVP_EncryptUpdate(ctx, (unsigned char*)encryptedMessage, &len, (const unsigned char*)message, strlen(message));
    encryptedLen += len;
    
    // Finalize the encryption
    EVP_EncryptFinal_ex(ctx, (unsigned char*)encryptedMessage + encryptedLen, &len);
    encryptedLen += len;

    EVP_CIPHER_CTX_free(ctx); // Free the context

    // Null-terminate the encrypted message
    encryptedMessage[encryptedLen] = '\0';
}



string hashPassword(const string& password, const string& salt) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    EVP_MD_CTX* mdctx;
    mdctx = EVP_MD_CTX_new();
    EVP_DigestInit_ex(mdctx, EVP_sha256(), NULL);
    EVP_DigestUpdate(mdctx, (password + salt).c_str(), (password + salt).length());
    EVP_DigestFinal_ex(mdctx, hash, NULL);
    EVP_MD_CTX_free(mdctx);

    stringstream ss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        ss << hex << (int)hash[i];
    }
    return ss.str();
}
// Function to verify password
bool verifyPassword(const string& password, const string& hashedPassword, const string& salt) {
    string hashed = hashPassword(password, salt);
    return hashed == hashedPassword;
}
void handleRegistration(int client_socket) {
    // Receive registration parameters from client
    char email[256], username[256], password[256];
    recv(client_socket, email, sizeof(email), 0);
    recv(client_socket, username, sizeof(username), 0);
    recv(client_socket, password, sizeof(password), 0);

    // Generate a random salt
    string salt;
    for (int i = 0; i < 16; i++) {
        salt += (char)(rand() % 256);
    }

    // Hash the password with salt
    string hashedPassword = hashPassword(password, salt);

    // Store the registration parameters in a file
    ofstream file("creds.txt", ios::app);
    file << username << ":" << salt << ":" << hashedPassword << endl;
    file.close();

    cout << "Registration successful!" << endl;
}

void handleLogin(int client_socket) {
    // Receive login parameters from client
    char username[256], password[256];
    recv(client_socket, username, sizeof(username), 0);
    recv(client_socket, password, sizeof(password), 0);

    // Retrieve the stored password and salt from the file
    ifstream file("creds.txt");
    string line;
    bool found = false;
    while (getline(file, line)) {
        size_t colon1 = line.find(":");
        size_t colon2 = line.find(":", colon1 + 1);
        string storedUsername = line.substr(0, colon1);
        string salt = line.substr(colon1 + 1, colon2 - colon1 - 1);
        string storedHashedPassword = line.substr(colon2 + 1);

        if (storedUsername == username) {
            found = true;
            // Verify the password
            if (verifyPassword(password, storedHashedPassword, salt)) {
                cout << "Login successful!" << endl;
            } else {
                cout << "Login failed!" << endl;
            }
            break;
        }
    }
    file.close();

    if (!found) {
        cout << "User  not found!" << endl;
    }
}
void DH_key_exchange(int sock) {

   srand(time(NULL));
   // Define the prime number and the base
    const unsigned long long prime = 17;  // A prime
    const unsigned long long alpha = 3;    // A base

    // Generate a random number for the server in the range [1, prime-1]
    unsigned long long serverSecret = rand() % (prime - 1) + 1;

    // Calculate the server's public value
    unsigned long long serverPublic = static_cast<unsigned long long>(pow(alpha, serverSecret)) % prime;

    // Send the server's public value to the client
    char serverPublicStr[256];
    snprintf(serverPublicStr, sizeof(serverPublicStr), "%llu", serverPublic);
    send(sock, serverPublicStr, strlen(serverPublicStr), 0);

    // Receive the client's public value
    char clientPublicStr[256];
    recv(sock, clientPublicStr, sizeof(clientPublicStr), 0);
    unsigned long long clientPublic = strtoull(clientPublicStr, nullptr, 10);

    // Calculate the shared secret key
    unsigned long long sharedSecret = static_cast<unsigned long long>(pow(clientPublic, serverSecret)) % prime;

    cout << "Server's Shared Secret Key: " << sharedSecret << endl;
    
    // Send the shared secret key to the client
    send(sock, reinterpret_cast<char*>(&sharedSecret), sizeof(sharedSecret), 0);
}




int main() {
    char buf[256];
    
    cout << "\n\t>>>>>>>>>> XYZ University Chat Server <<<<<<<<<<\n\n";
    
    cout << "Server is running...\n";
    // Create the server socket
    int server_socket;
    server_socket = socket(AF_INET, SOCK_STREAM, 0);

    // Define the server address
    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(8080);
    server_address.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket to the specified IP and port
    bind(server_socket, (struct sockaddr*) &server_address, sizeof(server_address));
    listen(server_socket, 5);

    while (true) {
        // Accept incoming connections
        int client_socket = accept(server_socket, NULL, NULL);

        // Create a new process to handle the client
        pid_t new_pid = fork();
        if (new_pid == -1) {
            // Error occurred while forking
            cout << "Error! Unable to fork process.\n";
        } else if (new_pid == 0) {
            // Child process handles the client
            close(server_socket); // Close the server socket in the child process
            
            // Receive the client's choice (login/register) after connection is accepted
            int choice;
            recv(client_socket, &choice, sizeof(choice), 0);
            cout << "Client choice received: " << choice << endl;

            if (choice == 1) 
            {
                handleLogin(client_socket);
            } 
            else if (choice == 2) 
            {
                handleRegistration(client_socket);
            }

            DH_key_exchange(client_socket);

            unsigned char iv[16];  // Initialization vector for AES
            char message[256];

            while (true) {
                memset(message, 0, sizeof(message));  // Clear the message buffer

                // Receive the shared secret
                unsigned long long receivedSharedSecret;
                recv(client_socket, (char*)&receivedSharedSecret, sizeof(receivedSharedSecret), 0);

                // Receive the IV from the client
                recv(client_socket, iv, sizeof(iv), 0);

                // Receive the encrypted message from the client
                recv(client_socket, message, sizeof(message), 0);

                // Decrypt the message
                char decryptedMessage[256];
                decryptMessage(message, decryptedMessage, receivedSharedSecret, iv);

                cout << "Client: " << decryptedMessage << endl;

                // Check for exit command
                if (strcmp(decryptedMessage, "exit") == 0) {
                    char response[256] = "exit";
                    encryptMessage(response, message, receivedSharedSecret, iv);
                    send(client_socket, message, strlen(message), 0);
                    break;
                }

                // Send response back to client
                char response[256];
                cout << "Server: ";
                cin.getline(response, sizeof(response));
                
                // Encrypt the response
                encryptMessage(response, message, receivedSharedSecret, iv);
                send(client_socket, message, strlen(message), 0);
            }

            // Close the client socket after communication
            close(client_socket);
            exit(0);  // Exit child process
        } else {
            // Parent process continues accepting clients
            close(client_socket);
        }
    }

    close(server_socket);
    return 0;
}
